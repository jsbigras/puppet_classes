#!/usr/bin/perl

# Contrary to other portals, this script for Facebook must be on a server accessible from the outside

# For debugging....
# use CGI::Carp qw(fatalsToBrowser);
use URI::Escape;

local ($buffer, @pairs, $pair, $name, $value);

# If user accepts....
# http://10.222.0.130/cgi-bin/sngtw-web-redirect-facebook.pl?wake_up_uri=http%3A%2F%2Ftheclient.uri.com%3A9000%3Fkey1%3Dvalue1%26key2%3Dvalue2&state=YOUR_STATE_VALUE&code=FacebookCode
# http://10.222.0.130/cgi-bin/sngtw-web-redirect-facebook.pl?wake_up_content_type=CONTENT_TYPE&state=YOUR_STATE_VALUE&code=FacebookCode
# If user denies
# http://10.222.0.130/cgi-bin/sngtw-web-redirect-facebook.pl?error_reason=user_denied&error=access_denied&error_description=The+user+denied+your+request.&state=YOUR_STATE_VALUE

$buffer = $ENV{'QUERY_STRING'};
@pairs = split(/&/, $buffer);
$wakeUpRedirectUri="";
$wakeUpContentType="";
$state="";
$code="";
$error="";
foreach $pair (@pairs)
{
    ($name, $value) = split(/=/, $pair);
    if ($name eq "wake_up_uri")
    {
       $wakeUpRedirectUri = uri_unescape($value);
    }
    elsif ($name eq "wake_up_content_type")
    {
       $wakeUpContentType = uri_unescape($value);
    }
    elsif ($name eq "state")
    {
       $state = $value;
    }
    elsif ($name eq "code")
    {
       $code = $value;
    }
    elsif ($name eq "error")
    {
       $error = $value;
    }
}

if ($wakeUpRedirectUri ne "")
{
    $redirect = "${wakeUpRedirectUri}";

    # Add query param separator... If redirect already contains ?, add &, otherwise, add ?
    if (${wakeUpRedirectUri} =~ /\?/)
    {
        $redirect .= "&";
    }
    else
    {
        $redirect .= "&";
    }

    if (${code} ne "")
    {
        $redirect .= "code=${code}";
        if (${state} ne "")
        {
            $redirect .= "&state=${state}";
        }
    }
    elsif (${error} ne "")
    {
        $redirect .= "error=${error}";
    }
    else
    {
        print "Status: 400 Bad Request\n\n";
        exit 0;
    }

#    print "Status: 200 OK\n";
#    print "X-test: ${redirect}\n\n";

    print "Status: 302 Moved\n";
    print "Location: ${redirect}\n\n";
}
elsif ($wakeUpContentType ne "")
{
    print "Status: 200 OK\n";
    # TODO: Need to return code, state or error.........
    print "Content-type: ${wakeUpContentType}\n\n";
}
elsif ($error ne "")
{
    print "Status: 403 Forbidden\n\n";
}
else
{
    print "Status: 400 Bad Request\n\n";
}
