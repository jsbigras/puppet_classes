#!/usr/bin/perl

use URI::Escape;

local ($buffer, @pairs, $pair, $name, $value);

# http://10.222.0.130/cgi-bin/sngtw-web-redirect-twitter.pl?wake_up_uri=http%3A%2F%2Ftheclient.uri.com%3A9000%3Fkey1%3Dvalue1%26key2%3Dvalue2&oauth_token=SlhcGZkqUAyNkUc0crf8AapePaqqwydkuFnopnJWslk&oauth_verifier=IyjtaFSgGBUhD56eNIfDkoTitbMds7QnKETlDrlbGo

$buffer = $ENV{'QUERY_STRING'};
@pairs = split(/&/, $buffer);
$wakeUpRedirectUri="";
$wakeUpContentType="";
$oauthToken="";
$oauthVerifier="";
foreach $pair (@pairs)
{
    ($name, $value) = split(/=/, $pair);
    if ($name eq "wake_up_uri")
    {
       $wakeUpRedirectUri = uri_unescape($value);
    }
    elsif ($name eq "wake_up_content_type")
    {
       $wakeUpContentType = uri_unescape($value);
    }
    elsif ($name eq "oauth_token")
    {
       $oauthToken = $value;
    }
    elsif ($name eq "oauth_verifier")
    {
       $oauthVerifier = $value;
    }
}

if ($wakeUpRedirectUri ne "")
{
    print "Status: 302 Moved\nLocation: ${wakeUpRedirectUri}";
    # add the oauth parameters: add ? or & depending on whether the client has query params
    if ($wakeUpRedirectUri =~ /\?/)
    {
        print("&");

    }
    else
    {
        print("?");
    }
    print("oauth_token=${oauthToken}&oauth_verifier=${oauthVerifier}\n\n");

}
elsif ($wakeUpContentType ne "")
{
    print "Status: 200 OK\n";
    print "Content-type: ${wakeUpContentType}\n\n";
}
else
{
    print "Status: 400 Bad Request\n\n";
}
